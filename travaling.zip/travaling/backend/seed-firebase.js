const { admin, db, initializeFirebase } = require('./db/firebase');
require('dotenv').config();

const samplePackages = [
  {
    name: 'Goa Beach Paradise',
    type: 'trip',
    description: 'Experience the beautiful beaches of Goa with our all-inclusive package.',
    price: 15000,
    location: 'Goa, India',
    duration: '4 Days 3 Nights',
    imageUrl: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=400',
    highlights: ['Beachfront resort', 'All meals included', 'Water sports', 'Airport transfers']
  },
  {
    name: 'Kerala Backwaters Tour',
    type: 'trip',
    description: 'Cruise through the serene backwaters of Kerala in a traditional houseboat.',
    price: 18000,
    location: 'Kerala, India',
    duration: '3 Days 2 Nights',
    imageUrl: 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=400',
    highlights: ['Houseboat stay', 'Traditional Kerala cuisine', 'Village tours', 'Ayurvedic spa']
  },
  {
    name: 'Rajasthan Royal Heritage',
    type: 'trip',
    description: 'Explore the majestic forts and palaces of Rajasthan.',
    price: 25000,
    location: 'Rajasthan, India',
    duration: '6 Days 5 Nights',
    imageUrl: 'https://images.unsplash.com/photo-1477587458883-47145ed94245?w=400',
    highlights: ['Palace stays', 'Camel safari', 'Cultural shows', 'Guided tours']
  },
  {
    name: 'Airport Transfer Service',
    type: 'cab',
    description: 'Comfortable and reliable airport pickup and drop service.',
    price: 1500,
    location: 'All major cities',
    duration: 'One way',
    imageUrl: 'https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?w=400',
    highlights: ['AC vehicles', 'Professional drivers', '24/7 service', 'Meet & greet']
  },
  {
    name: 'City Tour Cab',
    type: 'cab',
    description: 'Full day cab service for city sightseeing.',
    price: 2500,
    location: 'Available in all cities',
    duration: '8 hours',
    imageUrl: 'https://images.unsplash.com/photo-1562113430-ee861151bc49?w=400',
    highlights: ['AC sedan/SUV', 'Experienced drivers', 'Flexible itinerary', 'Fuel included']
  },
  {
    name: 'Outstation Cab Service',
    type: 'cab',
    description: 'Comfortable outstation travel with experienced drivers.',
    price: 12,
    location: 'Pan India',
    duration: 'Per kilometer',
    imageUrl: 'https://images.unsplash.com/photo-1566008885218-90abf9200ddb?w=400',
    highlights: ['Multiple car options', 'One way/Round trip', 'Driver allowance included', 'Toll charges extra']
  },
  {
    name: 'Traditional Thali Experience',
    type: 'food',
    description: 'Authentic regional thali with multiple dishes and desserts.',
    price: 500,
    location: 'Partner restaurants',
    duration: 'Per person',
    imageUrl: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=400',
    highlights: ['Vegetarian/Non-veg options', 'Unlimited servings', 'Traditional ambiance', 'Welcome drink']
  },
  {
    name: 'Street Food Walking Tour',
    type: 'food',
    description: 'Guided tour of the best street food spots in the city.',
    price: 800,
    location: 'Old city areas',
    duration: '3 hours',
    imageUrl: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=400',
    highlights: ['Expert food guide', '8-10 food stops', 'Hygiene assured', 'Small group tours']
  },
  {
    name: 'Luxury Dining Experience',
    type: 'food',
    description: 'Fine dining at premium restaurants with multi-course meals.',
    price: 3000,
    location: '5-star hotels',
    duration: 'Per couple',
    imageUrl: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=400',
    highlights: ['5-course meal', 'Premium beverages', 'Live music', 'Complimentary dessert']
  }
];

async function seedDatabase() {
  try {
    // Initialize Firebase
    initializeFirebase();
    
    console.log('Starting to seed Firebase database...');
    
    // Clear existing packages
    const packagesSnapshot = await db().collection('packages').get();
    const deletePromises = [];
    
    packagesSnapshot.forEach((doc) => {
      deletePromises.push(doc.ref.delete());
    });
    
    await Promise.all(deletePromises);
    console.log('Cleared existing packages');
    
    // Add sample packages
    const addPromises = samplePackages.map(async (packageData) => {
      const docData = {
        ...packageData,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      };
      
      const docRef = await db().collection('packages').add(docData);
      console.log(`Added package: ${packageData.name} (ID: ${docRef.id})`);
      return docRef;
    });
    
    await Promise.all(addPromises);
    
    console.log('\nFirebase database seeded successfully!');
    console.log(`Total packages added: ${samplePackages.length}`);
    
    // Show summary
    const summary = {};
    samplePackages.forEach(pkg => {
      summary[pkg.type] = (summary[pkg.type] || 0) + 1;
    });
    
    console.log('\nPackages by type:');
    Object.entries(summary).forEach(([type, count]) => {
      console.log(`- ${type}: ${count} packages`);
    });
    
    process.exit(0);
  } catch (error) {
    console.error('Error seeding database:', error);
    process.exit(1);
  }
}

seedDatabase();