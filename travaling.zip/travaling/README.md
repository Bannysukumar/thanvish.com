# Travel Booking Website

A dynamic travel booking website with admin CMS built using HTML, CSS, JavaScript, Node.js, Express, and MongoDB.

## Features

### User Side (Public)
- Browse available trips, cab services, and food experiences
- Filter packages by category
- View package details with images and highlights
- Book packages by filling a simple form
- No login required for browsing or booking

### Admin Panel
- Password-protected admin dashboard
- Full CRUD operations for packages
- View and manage booking requests
- Update booking status (pending/confirmed/cancelled)
- Real-time updates reflect on the frontend

## Setup Instructions

### Prerequisites
- Node.js (v14 or higher)
- MongoDB (running locally or MongoDB Atlas)

### Installation

1. **Clone/Navigate to the project**
   ```bash
   cd travel-booking-site
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Configure environment variables**
   - Edit `.env` file in the root directory
   - Update MongoDB URI if not using localhost
   - Change admin password from default

4. **Start MongoDB** (if running locally)
   ```bash
   mongod
   ```

5. **Seed sample data** (optional)
   ```bash
   npm run seed
   ```

6. **Start the server**
   ```bash
   npm start
   ```

7. **Access the website**
   - Public site: http://localhost:3000
   - Admin panel: http://localhost:3000/admin/login.html

## Default Credentials

- Admin Password: `admin123` (change in .env file)

## Project Structure

```
travel-booking-site/
├── public/          # Frontend files
├── admin/           # Admin panel files
├── models/          # MongoDB schemas
├── db/              # Database connection
├── server.js        # Express server
├── seed.js          # Sample data script
└── .env             # Environment variables
```

## API Endpoints

- `GET /api/packages` - Get all packages
- `POST /api/packages` - Add new package (admin)
- `PUT /api/packages/:id` - Update package (admin)
- `DELETE /api/packages/:id` - Delete package (admin)
- `POST /api/bookings` - Submit booking request
- `GET /api/bookings` - Get all bookings (admin)

## Technologies Used

- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Backend**: Node.js, Express.js
- **Database**: MongoDB with Mongoose
- **Authentication**: Basic password protection for admin
- **Styling**: Custom CSS with responsive design