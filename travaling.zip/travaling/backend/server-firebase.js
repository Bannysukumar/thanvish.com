const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

const { admin, db, initializeFirebase } = require('./db/firebase');

const app = express();
const PORT = process.env.PORT || 3000;

// Initialize Firebase
initializeFirebase();

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../frontend/public')));
app.use('/admin', express.static(path.join(__dirname, '../frontend/admin')));

// Admin auth middleware
const adminAuth = async (req, res, next) => {
  const password = req.headers.authorization;
  const adminPassword = process.env.ADMIN_PASSWORD || 'admin123';
  
  if (!password || password !== adminPassword) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
};

// Package Routes
app.get('/api/packages', async (req, res) => {
  try {
    const { type } = req.query;
    let packagesRef = db().collection('packages');
    
    if (type) {
      packagesRef = packagesRef.where('type', '==', type);
    }
    
    const snapshot = await packagesRef.orderBy('createdAt', 'desc').get();
    const packages = [];
    
    snapshot.forEach(doc => {
      const data = doc.data();
      
      // Convert Firebase timestamps to JSON-serializable format
      if (data.createdAt && data.createdAt._seconds) {
        data.createdAt = {
          _seconds: data.createdAt._seconds,
          _nanoseconds: data.createdAt._nanoseconds
        };
      }
      
      if (data.updatedAt && data.updatedAt._seconds) {
        data.updatedAt = {
          _seconds: data.updatedAt._seconds,
          _nanoseconds: data.updatedAt._nanoseconds
        };
      }
      
      packages.push({ _id: doc.id, ...data });
    });
    
    res.json(packages);
  } catch (error) {
    console.error('Error fetching packages:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/packages/:id', async (req, res) => {
  try {
    const doc = await db().collection('packages').doc(req.params.id).get();
    
    if (!doc.exists) {
      return res.status(404).json({ error: 'Package not found' });
    }
    
    res.json({ _id: doc.id, ...doc.data() });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/packages', adminAuth, async (req, res) => {
  try {
    const packageData = {
      ...req.body,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };
    
    const docRef = await db().collection('packages').add(packageData);
    const doc = await docRef.get();
    
    res.status(201).json({ _id: doc.id, ...doc.data() });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.put('/api/packages/:id', adminAuth, async (req, res) => {
  try {
    const packageRef = db().collection('packages').doc(req.params.id);
    const doc = await packageRef.get();
    
    if (!doc.exists) {
      return res.status(404).json({ error: 'Package not found' });
    }
    
    const updateData = {
      ...req.body,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };
    
    await packageRef.update(updateData);
    const updatedDoc = await packageRef.get();
    
    res.json({ _id: updatedDoc.id, ...updatedDoc.data() });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.delete('/api/packages/:id', adminAuth, async (req, res) => {
  try {
    const packageRef = db().collection('packages').doc(req.params.id);
    const doc = await packageRef.get();
    
    if (!doc.exists) {
      return res.status(404).json({ error: 'Package not found' });
    }
    
    await packageRef.delete();
    res.json({ message: 'Package deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Booking Routes
app.post('/api/bookings', async (req, res) => {
  try {
    const bookingData = {
      ...req.body,
      status: 'pending',
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    };
    
    const docRef = await db().collection('bookings').add(bookingData);
    const doc = await docRef.get();
    
    res.status(201).json({ 
      message: 'Thank you! Your booking request has been received. Admin will contact you soon.',
      booking: { _id: doc.id, ...doc.data() }
    });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get('/api/bookings', adminAuth, async (req, res) => {
  try {
    const snapshot = await db().collection('bookings')
      .orderBy('createdAt', 'desc')
      .get();
    
    const bookings = [];
    
    for (const doc of snapshot.docs) {
      const bookingData = doc.data();
      
      // Convert Firebase timestamps to JSON-serializable format
      if (bookingData.createdAt && bookingData.createdAt._seconds) {
        bookingData.createdAt = {
          _seconds: bookingData.createdAt._seconds,
          _nanoseconds: bookingData.createdAt._nanoseconds
        };
      }
      
      if (bookingData.updatedAt && bookingData.updatedAt._seconds) {
        bookingData.updatedAt = {
          _seconds: bookingData.updatedAt._seconds,
          _nanoseconds: bookingData.updatedAt._nanoseconds
        };
      }
      
      // Get package details if packageId exists
      if (bookingData.packageId) {
        const packageDoc = await db().collection('packages').doc(bookingData.packageId).get();
        if (packageDoc.exists) {
          bookingData.package = { _id: packageDoc.id, ...packageDoc.data() };
        }
      }
      
      bookings.push({ _id: doc.id, ...bookingData });
    }
    
    res.json(bookings);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.patch('/api/bookings/:id/status', adminAuth, async (req, res) => {
  try {
    const { status } = req.body;
    const bookingRef = db().collection('bookings').doc(req.params.id);
    const doc = await bookingRef.get();
    
    if (!doc.exists) {
      return res.status(404).json({ error: 'Booking not found' });
    }
    
    await bookingRef.update({ 
      status,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });
    
    const updatedDoc = await bookingRef.get();
    res.json({ _id: updatedDoc.id, ...updatedDoc.data() });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Admin login
app.post('/api/admin/login', async (req, res) => {
  const { password } = req.body;
  const adminPassword = process.env.ADMIN_PASSWORD || 'admin123';
  
  if (password === adminPassword) {
    res.json({ success: true, message: 'Login successful' });
  } else {
    res.status(401).json({ error: 'Invalid password' });
  }
});

app.listen(PORT, () => {
  console.log(`Server (Firebase) running on http://localhost:${PORT}`);
});