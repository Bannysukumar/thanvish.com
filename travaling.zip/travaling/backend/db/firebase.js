const admin = require('firebase-admin');

// Initialize Firebase Admin
const initializeFirebase = () => {
  try {
    // Check if we're using the emulator
    const useEmulator = process.env.USE_FIREBASE_EMULATOR === 'true';
    
    if (useEmulator) {
      // Use the Firebase emulator
      process.env.FIRESTORE_EMULATOR_HOST = process.env.FIRESTORE_EMULATOR_HOST || 'localhost:8080';
      admin.initializeApp({
        projectId: process.env.FIREBASE_PROJECT_ID || 'travel-booking-demo'
      });
      console.log('Firebase initialized with emulator at:', process.env.FIRESTORE_EMULATOR_HOST);
    } else {
      // Clear emulator host if set
      delete process.env.FIRESTORE_EMULATOR_HOST;
      
      // Use real Firebase (requires service account key)
      try {
        const serviceAccount = require('../serviceAccountKey.json');
        admin.initializeApp({
          credential: admin.credential.cert(serviceAccount)
        });
        console.log('Firebase initialized with service account');
      } catch (error) {
        // Fallback to application default credentials
        admin.initializeApp({
          projectId: process.env.FIREBASE_PROJECT_ID || 'travel-booking-demo'
        });
        console.log('Firebase initialized with default credentials');
      }
    }
    
    console.log('Firebase initialized successfully');
  } catch (error) {
    console.error('Firebase initialization error:', error);
  }
};

const db = () => admin.firestore();

module.exports = {
  admin,
  db,
  initializeFirebase
};