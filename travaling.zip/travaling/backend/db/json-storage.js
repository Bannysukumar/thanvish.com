const fs = require('fs');
const path = require('path');

// JSON storage paths
const PACKAGES_FILE = path.join(__dirname, '../data/packages.json');
const BOOKINGS_FILE = path.join(__dirname, '../data/bookings.json');

// Ensure data directory exists
const dataDir = path.dirname(PACKAGES_FILE);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Initialize files if they don't exist
if (!fs.existsSync(PACKAGES_FILE)) {
  fs.writeFileSync(PACKAGES_FILE, JSON.stringify([]));
}
if (!fs.existsSync(BOOKINGS_FILE)) {
  fs.writeFileSync(BOOKINGS_FILE, JSON.stringify([]));
}

// Helper functions
const readFile = (filePath) => {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (error) {
    return [];
  }
};

const writeFile = (filePath, data) => {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
};

const generateId = () => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

// Package operations
const PackageStorage = {
  find: (filter = {}) => {
    const packages = readFile(PACKAGES_FILE);
    if (filter.type) {
      return packages.filter(pkg => pkg.type === filter.type);
    }
    return packages;
  },

  findById: (id) => {
    const packages = readFile(PACKAGES_FILE);
    return packages.find(pkg => pkg.id === id);
  },

  create: (packageData) => {
    const packages = readFile(PACKAGES_FILE);
    const newPackage = {
      id: generateId(),
      ...packageData,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    packages.push(newPackage);
    writeFile(PACKAGES_FILE, packages);
    return newPackage;
  },

  update: (id, updateData) => {
    const packages = readFile(PACKAGES_FILE);
    const index = packages.findIndex(pkg => pkg.id === id);
    if (index !== -1) {
      packages[index] = {
        ...packages[index],
        ...updateData,
        updatedAt: new Date().toISOString()
      };
      writeFile(PACKAGES_FILE, packages);
      return packages[index];
    }
    return null;
  },

  delete: (id) => {
    const packages = readFile(PACKAGES_FILE);
    const index = packages.findIndex(pkg => pkg.id === id);
    if (index !== -1) {
      const deleted = packages.splice(index, 1)[0];
      writeFile(PACKAGES_FILE, packages);
      return deleted;
    }
    return null;
  }
};

// Booking operations
const BookingStorage = {
  find: () => {
    const bookings = readFile(BOOKINGS_FILE);
    const packages = readFile(PACKAGES_FILE);
    
    return bookings.map(booking => {
      const packageInfo = packages.find(pkg => pkg.id === booking.packageId);
      return {
        ...booking,
        packageInfo
      };
    });
  },

  create: (bookingData) => {
    const bookings = readFile(BOOKINGS_FILE);
    const newBooking = {
      id: generateId(),
      ...bookingData,
      status: 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    bookings.push(newBooking);
    writeFile(BOOKINGS_FILE, bookings);
    return newBooking;
  },

  updateStatus: (id, status) => {
    const bookings = readFile(BOOKINGS_FILE);
    const index = bookings.findIndex(booking => booking.id === id);
    if (index !== -1) {
      bookings[index].status = status;
      bookings[index].updatedAt = new Date().toISOString();
      writeFile(BOOKINGS_FILE, bookings);
      return bookings[index];
    }
    return null;
  }
};

module.exports = {
  PackageStorage,
  BookingStorage
};