# aaPanel Deployment Guide - Travel Booking Site

## Prerequisites
- aaPanel installed on your server
- Node.js (v14 or higher) installed via aaPanel
- PM2 installed globally: `npm install -g pm2`
- Domain pointed to your server

## Step 1: Upload Files to aaPanel

1. **Create Website in aaPanel:**
   - Go to Website → Add Site
   - Enter your domain name
   - Set document root to `/www/wwwroot/your-domain.com`

2. **Upload Project Files:**
   - Upload all project files to `/www/wwwroot/your-domain.com/`
   - Or use Git to clone the repository

## Step 2: Install Dependencies

```bash
cd /www/wwwroot/your-domain.com
npm install --production
```

## Step 3: Configure Environment

1. **Copy environment file:**
   ```bash
   cp .env.production .env
   ```

2. **Edit .env file:**
   ```bash
   nano .env
   ```
   Update the following:
   - `ADMIN_PASSWORD` - Set a secure admin password
   - `PORT` - Usually 3000 (or as configured in aaPanel)
   - `FIREBASE_PROJECT_ID` - Your Firebase project ID

3. **Upload Firebase Service Account Key:**
   - Place your Firebase service account JSON file in `/backend/` directory
   - Ensure file permissions are set to 600

## Step 4: Configure Reverse Proxy in aaPanel

1. **Go to Website → your-domain.com → Reverse Proxy**
2. **Add Proxy:**
   - Target URL: `http://127.0.0.1:3000`
   - Proxy directory: `/`
   - Enable: "Cache", "Pass Host Header"

## Step 5: Start Application with PM2

```bash
# Navigate to project directory
cd /www/wwwroot/your-domain.com

# Start with PM2
pm2 start ecosystem.config.js --env production

# Save PM2 process list
pm2 save

# Setup PM2 to start on boot
pm2 startup
```

## Step 6: Configure aaPanel App Manager (Alternative)

1. **Go to App Store → System Tools → Supervisor**
2. **Add Daemon:**
   - Name: `travel-booking-site`
   - User: `www`
   - Command: `/usr/bin/node /www/wwwroot/your-domain.com/backend/server-firebase.js`
   - Directory: `/www/wwwroot/your-domain.com`
   - Auto Start: Yes
   - Auto Restart: Yes

## Step 7: SSL Certificate (Optional but Recommended)

1. **Go to Website → your-domain.com → SSL**
2. **Choose SSL Provider:**
   - Let's Encrypt (Free)
   - Or upload your own certificate
3. **Force HTTPS redirect**

## Step 8: Firewall Configuration

Ensure the following ports are open in aaPanel Security:
- Port 80 (HTTP)
- Port 443 (HTTPS)
- Port 3000 (Application) - Only if not using reverse proxy

## Monitoring & Maintenance

### PM2 Commands:
```bash
pm2 list                    # List all processes
pm2 restart travel-booking-site  # Restart app
pm2 stop travel-booking-site     # Stop app
pm2 logs travel-booking-site     # View logs
pm2 monit                   # Monitor processes
```

### Log Files:
- Application logs: `/www/wwwroot/your-domain.com/logs/`
- aaPanel logs: Available in aaPanel dashboard

### Database Management:
- **Firebase Console:** Monitor your Firebase Firestore database
- **Admin Panel:** Access at `https://your-domain.com/admin/login.html`

## Troubleshooting

### Common Issues:

1. **"Cannot GET /" Error:**
   - Check file permissions: `chmod -R 755 frontend/`
   - Verify reverse proxy configuration

2. **Firebase Connection Issues:**
   - Verify service account key file exists
   - Check Firebase project ID in .env
   - Ensure server has internet access

3. **Admin Login Issues:**
   - Verify ADMIN_PASSWORD in .env file
   - Check admin panel at `/admin/login.html`

4. **Port Already in Use:**
   - Change PORT in .env file
   - Update reverse proxy configuration
   - Restart the application

### Performance Optimization:
- Enable Gzip compression in aaPanel
- Use CDN for static assets
- Monitor resource usage in aaPanel dashboard

## Security Checklist:
- [ ] Strong admin password set
- [ ] Firebase service account key secured (600 permissions)
- [ ] SSL certificate installed
- [ ] Regular backups enabled in aaPanel
- [ ] Firewall properly configured

## Support:
- Firebase documentation: https://firebase.google.com/docs
- aaPanel documentation: https://www.aapanel.com/
- PM2 documentation: https://pm2.keymetrics.io/docs/