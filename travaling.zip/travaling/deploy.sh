#!/bin/bash

# Quick Deploy Script for aaPanel
# Run this script after uploading files to your aaPanel server

echo "🚀 Deploying Travel Booking Site to aaPanel..."

# Check if we're in the correct directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: Please run this script from the project root directory"
    exit 1
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install --production

# Setup environment
echo "⚙️  Setting up environment..."
if [ ! -f ".env" ]; then
    cp .env.production .env
    echo "📝 .env file created from template. Please edit it with your settings."
fi

# Create logs directory
mkdir -p logs

# Set proper permissions
echo "🔐 Setting file permissions..."
chmod +x start.sh
chmod -R 755 frontend/
chmod 600 backend/*.json 2>/dev/null || true

# Install PM2 globally if not present
echo "🔧 Checking PM2..."
if ! command -v pm2 &> /dev/null; then
    echo "Installing PM2..."
    npm install -g pm2
fi

# Start application with PM2
echo "🎯 Starting application..."
pm2 start ecosystem.config.js --env production

# Save PM2 configuration
pm2 save

echo "✅ Deployment complete!"
echo ""
echo "Next steps:"
echo "1. Configure reverse proxy in aaPanel (port 3000 → your domain)"
echo "2. Edit .env file with your production settings"
echo "3. Upload Firebase service account key to backend/ directory"
echo "4. Setup SSL certificate in aaPanel"
echo ""
echo "🌐 Your site should be accessible at: http://your-domain.com"
echo "🛠️  Admin panel: http://your-domain.com/admin/login.html"
echo ""
echo "📊 Monitor with: pm2 monit"
echo "📝 View logs with: pm2 logs travel-booking-site"