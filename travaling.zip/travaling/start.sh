#!/bin/bash

# Travel Booking Site - Production Startup Script for aaPanel

echo "Starting Travel Booking Site..."

# Set production environment
export NODE_ENV=production

# Change to application directory
cd /www/wwwroot/your-domain.com

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm install --production
fi

# Start the Firebase server
echo "Starting Firebase server..."
npm run start:firebase

# Keep the script running
wait