# Firebase Setup Guide

## Option 1: Using Firebase Emulator (Recommended for Development)

1. Install Firebase CLI globally:
```bash
npm install -g firebase-tools
```

2. Initialize Firebase in the project:
```bash
firebase init
```
- Select "Firestore" when prompted
- Use the default options

3. Start the Firebase emulator:
```bash
firebase emulators:start --only firestore
```

4. In another terminal, run the server:
```bash
npm run start:firebase
```

## Option 2: Using Real Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Create a new project
3. Enable Firestore Database
4. Go to Project Settings > Service Accounts
5. Generate a new private key
6. Save the JSON file as `serviceAccountKey.json` in the project root
7. Update `.env` with your project ID:
```
FIREBASE_PROJECT_ID=your-project-id
```

8. Update `db/firebase.js` to use the service account:
```javascript
const serviceAccount = require('../serviceAccountKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});
```

## Running the Application

1. Seed the database:
```bash
npm run seed:firebase
```

2. Start the server:
```bash
npm run start:firebase
```

3. Access the application at http://localhost:3000

## Notes

- The Firebase version uses Firestore instead of MongoDB
- All data structures have been adapted for Firestore
- The API endpoints remain the same for compatibility
- Admin authentication works the same way