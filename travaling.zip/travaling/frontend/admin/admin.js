const API_URL = 'http://localhost:3000/api';
let adminPassword = localStorage.getItem('adminPassword');
let currentPackageFilter = 'all';
let packages = [];
let bookings = [];

// Check authentication
if (!adminPassword) {
    window.location.href = 'login.html';
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadPackages();
    loadBookings();
    setupEventListeners();
});

function setupEventListeners() {
    // Section navigation
    document.querySelectorAll('.sidebar nav a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            if (link.id === 'logout') {
                logout();
                return;
            }
            const section = link.dataset.section;
            showSection(section);
        });
    });

    // Package filters
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelector('.filter-btn.active').classList.remove('active');
            btn.classList.add('active');
            currentPackageFilter = btn.dataset.type;
            displayPackages();
        });
    });

    // Modal
    document.querySelector('.close').addEventListener('click', closePackageModal);
    document.getElementById('package-form').addEventListener('submit', handlePackageSubmit);
}

function showSection(section) {
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.sidebar nav a').forEach(a => a.classList.remove('active'));
    
    document.getElementById(`${section}-section`).classList.add('active');
    document.querySelector(`[data-section="${section}"]`).classList.add('active');
}

async function loadPackages() {
    try {
        const response = await fetch(`${API_URL}/packages`);
        packages = await response.json();
        displayPackages();
    } catch (error) {
        console.error('Error loading packages:', error);
    }
}

function displayPackages() {
    const filteredPackages = currentPackageFilter === 'all'
        ? packages
        : packages.filter(pkg => pkg.type === currentPackageFilter);

    const container = document.getElementById('packages-list');
    
    if (filteredPackages.length === 0) {
        container.innerHTML = '<p>No packages found.</p>';
        return;
    }

    container.innerHTML = filteredPackages.map(pkg => `
        <div class="package-item">
            <div class="package-header">
                <div>
                    <h3>${pkg.name}</h3>
                    <span class="package-type-badge ${pkg.type}">${pkg.type.toUpperCase()}</span>
                </div>
                <div class="package-actions">
                    <button class="btn-edit" onclick="editPackage('${pkg._id}')">Edit</button>
                    <button class="btn-delete" onclick="deletePackage('${pkg._id}')">Delete</button>
                </div>
            </div>
            <p>${pkg.description}</p>
            <p><strong>Price:</strong> ₹${pkg.price.toLocaleString()}</p>
            ${pkg.location ? `<p><strong>Location:</strong> ${pkg.location}</p>` : ''}
            ${pkg.duration ? `<p><strong>Duration:</strong> ${pkg.duration}</p>` : ''}
        </div>
    `).join('');
}

async function loadBookings() {
    try {
        const response = await fetch(`${API_URL}/bookings`, {
            headers: {
                'Authorization': adminPassword
            }
        });
        bookings = await response.json();
        displayBookings();
    } catch (error) {
        console.error('Error loading bookings:', error);
    }
}

// Helper function to convert Firebase timestamp to Date
function formatFirebaseDate(timestamp) {
    if (!timestamp) return 'N/A';
    
    // Handle Firebase Timestamp object
    if (timestamp._seconds) {
        return new Date(timestamp._seconds * 1000).toLocaleString();
    }
    
    // Handle regular date string
    if (typeof timestamp === 'string') {
        return new Date(timestamp).toLocaleString();
    }
    
    // Handle milliseconds timestamp
    if (typeof timestamp === 'number') {
        return new Date(timestamp).toLocaleString();
    }
    
    return 'Invalid Date';
}

function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return isNaN(date.getTime()) ? 'N/A' : date.toLocaleDateString();
}

function displayBookings() {
    const container = document.getElementById('bookings-list');
    
    if (bookings.length === 0) {
        container.innerHTML = '<p style="padding: 2rem;">No bookings yet.</p>';
        return;
    }

    container.innerHTML = bookings.map(booking => `
        <div class="booking-item">
            <div class="booking-header">
                <div>
                    <h3>${booking.customerName}</h3>
                    <span class="booking-status ${booking.status}">${booking.status.toUpperCase()}</span>
                </div>
                <div>
                    <select onchange="updateBookingStatus('${booking._id}', this.value)">
                        <option value="pending" ${booking.status === 'pending' ? 'selected' : ''}>Pending</option>
                        <option value="confirmed" ${booking.status === 'confirmed' ? 'selected' : ''}>Confirmed</option>
                        <option value="cancelled" ${booking.status === 'cancelled' ? 'selected' : ''}>Cancelled</option>
                    </select>
                </div>
            </div>
            <p><strong>Package:</strong> ${booking.packageName}</p>
            <p><strong>Mobile:</strong> ${booking.mobileNumber}</p>
            ${booking.email ? `<p><strong>Email:</strong> ${booking.email}</p>` : ''}
            <p><strong>Persons:</strong> ${booking.numberOfPersons}</p>
            <p><strong>Dates:</strong> ${formatDate(booking.preferredDates.start)} 
                ${booking.preferredDates.end ? `- ${formatDate(booking.preferredDates.end)}` : ''}</p>
            ${booking.additionalNotes ? `<p><strong>Notes:</strong> ${booking.additionalNotes}</p>` : ''}
            <p><small>Booked on: ${formatFirebaseDate(booking.createdAt)}</small></p>
        </div>
    `).join('');
}

function showAddPackageForm() {
    document.getElementById('modal-title').textContent = 'Add New Package';
    document.getElementById('package-form').reset();
    document.getElementById('package-id').value = '';
    document.getElementById('package-modal').style.display = 'block';
}

function editPackage(id) {
    const pkg = packages.find(p => p._id === id);
    if (!pkg) return;

    document.getElementById('modal-title').textContent = 'Edit Package';
    document.getElementById('package-id').value = pkg._id;
    document.getElementById('package-name').value = pkg.name;
    document.getElementById('package-type').value = pkg.type;
    document.getElementById('package-description').value = pkg.description;
    document.getElementById('package-price').value = pkg.price;
    document.getElementById('package-location').value = pkg.location || '';
    document.getElementById('package-duration').value = pkg.duration || '';
    document.getElementById('package-image').value = pkg.imageUrl || '';
    document.getElementById('package-highlights').value = pkg.highlights ? pkg.highlights.join(', ') : '';
    
    document.getElementById('package-modal').style.display = 'block';
}

function closePackageModal() {
    document.getElementById('package-modal').style.display = 'none';
    document.getElementById('package-form').reset();
}

async function handlePackageSubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const packageId = document.getElementById('package-id').value;
    
    const packageData = {
        name: formData.get('name'),
        type: formData.get('type'),
        description: formData.get('description'),
        price: parseFloat(formData.get('price')),
        location: formData.get('location'),
        duration: formData.get('duration'),
        imageUrl: formData.get('imageUrl') || 'https://via.placeholder.com/400x300',
        highlights: formData.get('highlights') ? formData.get('highlights').split(',').map(h => h.trim()) : []
    };

    try {
        const url = packageId 
            ? `${API_URL}/packages/${packageId}`
            : `${API_URL}/packages`;
        
        const method = packageId ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': adminPassword
            },
            body: JSON.stringify(packageData)
        });

        if (response.ok) {
            closePackageModal();
            loadPackages();
            alert(packageId ? 'Package updated successfully!' : 'Package added successfully!');
        } else {
            const error = await response.json();
            alert('Error: ' + error.error);
        }
    } catch (error) {
        console.error('Error saving package:', error);
        alert('Error saving package. Please try again.');
    }
}

async function deletePackage(id) {
    if (!confirm('Are you sure you want to delete this package?')) return;

    try {
        const response = await fetch(`${API_URL}/packages/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': adminPassword
            }
        });

        if (response.ok) {
            loadPackages();
            alert('Package deleted successfully!');
        } else {
            const error = await response.json();
            alert('Error: ' + error.error);
        }
    } catch (error) {
        console.error('Error deleting package:', error);
        alert('Error deleting package. Please try again.');
    }
}

async function updateBookingStatus(id, status) {
    try {
        const response = await fetch(`${API_URL}/bookings/${id}/status`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': adminPassword
            },
            body: JSON.stringify({ status })
        });

        if (response.ok) {
            loadBookings();
        } else {
            const error = await response.json();
            alert('Error: ' + error.error);
        }
    } catch (error) {
        console.error('Error updating booking status:', error);
        alert('Error updating booking status. Please try again.');
    }
}

function logout() {
    localStorage.removeItem('adminPassword');
    window.location.href = 'login.html';
}