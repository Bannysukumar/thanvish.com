const { admin, db, initializeFirebase } = require('./db/firebase');
require('dotenv').config();

async function testFirebase() {
  try {
    console.log('Testing Firebase connection...');
    initializeFirebase();
    
    // Test reading packages
    const snapshot = await db().collection('packages').limit(2).get();
    
    console.log('\nPackages found:', snapshot.size);
    snapshot.forEach(doc => {
      console.log('- ID:', doc.id);
      console.log('  Data:', doc.data().name);
    });
    
    console.log('\nFirebase connection successful!');
    process.exit(0);
  } catch (error) {
    console.error('Firebase test failed:', error);
    process.exit(1);
  }
}

testFirebase();