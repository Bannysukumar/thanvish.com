const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const path = require('path');
require('dotenv').config({ path: '../.env' });

const { packageStorage, bookingStorage } = require('./json-storage');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('../frontend/public'));

// Admin credentials
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';

// Routes
// Get all packages
app.get('/api/packages', async (req, res) => {
  try {
    const packages = await packageStorage.find();
    res.json(packages);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch packages' });
  }
});

// Get packages by type
app.get('/api/packages/type/:type', async (req, res) => {
  try {
    const packages = await packageStorage.find({ type: req.params.type });
    res.json(packages);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch packages' });
  }
});

// Get single package
app.get('/api/packages/:id', async (req, res) => {
  try {
    const package = await packageStorage.findById(req.params.id);
    if (!package) {
      return res.status(404).json({ error: 'Package not found' });
    }
    res.json(package);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch package' });
  }
});

// Admin login
app.post('/api/admin/login', async (req, res) => {
  try {
    const { password } = req.body;
    
    if (password === ADMIN_PASSWORD) {
      res.json({ success: true, message: 'Login successful' });
    } else {
      res.status(401).json({ success: false, message: 'Invalid password' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Login failed' });
  }
});

// Add new package (admin only)
app.post('/api/admin/packages', async (req, res) => {
  try {
    const packageData = req.body;
    const newPackage = await packageStorage.create(packageData);
    res.json(newPackage);
  } catch (error) {
    res.status(500).json({ error: 'Failed to add package' });
  }
});

// Update package (admin only)
app.put('/api/admin/packages/:id', async (req, res) => {
  try {
    const updatedPackage = await packageStorage.updateById(req.params.id, req.body);
    if (!updatedPackage) {
      return res.status(404).json({ error: 'Package not found' });
    }
    res.json(updatedPackage);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update package' });
  }
});

// Delete package (admin only)
app.delete('/api/admin/packages/:id', async (req, res) => {
  try {
    const deletedPackage = await packageStorage.deleteById(req.params.id);
    if (!deletedPackage) {
      return res.status(404).json({ error: 'Package not found' });
    }
    res.json({ message: 'Package deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete package' });
  }
});

// Get all bookings (admin only)
app.get('/api/admin/bookings', async (req, res) => {
  try {
    const bookings = await bookingStorage.find();
    res.json(bookings);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch bookings' });
  }
});

// Create booking
app.post('/api/bookings', async (req, res) => {
  try {
    const bookingData = req.body;
    const newBooking = await bookingStorage.create(bookingData);
    res.json(newBooking);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create booking' });
  }
});

// Update booking status (admin only)
app.put('/api/admin/bookings/:id', async (req, res) => {
  try {
    const updatedBooking = await bookingStorage.updateById(req.params.id, req.body);
    if (!updatedBooking) {
      return res.status(404).json({ error: 'Booking not found' });
    }
    res.json(updatedBooking);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update booking' });
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'Server is running with JSON storage' });
});

// Serve admin files
app.use('/admin', express.static('admin'));

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log('Using JSON file storage (no database required)');
});

module.exports = app;