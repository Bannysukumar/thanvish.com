const API_URL = 'http://localhost:3000/api';
let currentFilter = 'all';
let packages = [];

// Load packages on page load
document.addEventListener('DOMContentLoaded', () => {
    loadPackages();
    setupEventListeners();
    setupScrollAnimations();
    setupParallaxEffect();
    
    // Add search functionality
    document.getElementById('search-input').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            searchPackages();
        }
    });
});

function setupEventListeners() {
    // Filter links
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            document.querySelector('.nav-links a.active').classList.remove('active');
            link.classList.add('active');
            currentFilter = link.dataset.filter;
            displayPackages();
        });
    });

    // Modal close
    document.querySelector('.close').addEventListener('click', closeModal);
    window.addEventListener('click', (e) => {
        if (e.target === document.getElementById('booking-modal')) {
            closeModal();
        }
    });

    // Form submission
    document.getElementById('booking-form').addEventListener('submit', handleBookingSubmit);
}

async function loadPackages() {
    showLoader();
    try {
        const response = await fetch(`${API_URL}/packages`);
        packages = await response.json();
        hideLoader();
        displayPackages();
    } catch (error) {
        console.error('Error loading packages:', error);
        hideLoader();
        document.getElementById('packages-container').innerHTML = 
            '<p>Error loading packages. Please try again later.</p>';
    }
}

function showLoader() {
    document.getElementById('loader').style.display = 'flex';
    document.getElementById('packages-container').style.display = 'none';
}

function hideLoader() {
    document.getElementById('loader').style.display = 'none';
    document.getElementById('packages-container').style.display = 'grid';
}


function openBookingModal(packageId, packageName) {
    document.getElementById('package-id').value = packageId;
    document.getElementById('package-name').value = packageName;
    document.getElementById('booking-modal').style.display = 'block';
    
    // Set minimum date to today
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('start-date').min = today;
    document.getElementById('end-date').min = today;
}

function closeModal() {
    document.getElementById('booking-modal').style.display = 'none';
    document.getElementById('booking-form').reset();
}

async function handleBookingSubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const bookingData = {
        packageId: formData.get('packageId'),
        packageName: formData.get('packageName'),
        customerName: formData.get('customerName'),
        mobileNumber: formData.get('mobileNumber'),
        email: formData.get('email'),
        numberOfPersons: parseInt(formData.get('numberOfPersons')),
        preferredDates: {
            start: formData.get('startDate'),
            end: formData.get('endDate')
        },
        additionalNotes: formData.get('additionalNotes')
    };

    try {
        const response = await fetch(`${API_URL}/bookings`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(bookingData)
        });

        const result = await response.json();

        if (response.ok) {
            closeModal();
            showSuccessMessage();
        } else {
            alert('Error: ' + result.error);
        }
    } catch (error) {
        console.error('Error submitting booking:', error);
        alert('Error submitting booking. Please try again.');
    }
}

function showSuccessMessage() {
    document.getElementById('success-message').style.display = 'block';
}

function closeSuccess() {
    document.getElementById('success-message').style.display = 'none';
}

// Scroll-triggered animations
function setupScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
            }
        });
    }, observerOptions);

    // Observe all scroll-reveal elements
    document.querySelectorAll('.scroll-reveal').forEach(el => {
        observer.observe(el);
    });
}

// Parallax scrolling effect
function setupParallaxEffect() {
    const parallaxElements = document.querySelectorAll('.parallax');
    
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        const rate = scrolled * -0.3;
        
        parallaxElements.forEach(element => {
            element.style.transform = `translateY(${rate}px)`;
        });
    });
}

// Enhanced package display with staggered animations
function displayPackages() {
    const container = document.getElementById('packages-container');
    const filteredPackages = currentFilter === 'all' 
        ? packages 
        : packages.filter(pkg => pkg.type === currentFilter);

    if (filteredPackages.length === 0) {
        container.innerHTML = '<p>No packages available in this category.</p>';
        return;
    }

    container.innerHTML = filteredPackages.map((pkg, index) => `
        <div class="package-card stagger-item" style="animation-delay: ${index * 0.1}s">
            <img src="${pkg.imageUrl}" alt="${pkg.name}" class="package-image">
            <div class="package-content">
                <span class="package-type ${pkg.type}">${pkg.type.toUpperCase()}</span>
                <h3 class="package-title">${pkg.name}</h3>
                <p class="package-description">${pkg.description}</p>
                ${pkg.location ? `<p><strong>Location:</strong> ${pkg.location}</p>` : ''}
                ${pkg.duration ? `<p><strong>Duration:</strong> ${pkg.duration}</p>` : ''}
                <div class="package-price">₹${pkg.price.toLocaleString()}</div>
                <button class="btn-primary" onclick="openBookingModal('${pkg._id}', '${pkg.name}')">
                    Book Now
                </button>
            </div>
        </div>
    `).join('');
    
    // Re-trigger stagger animation
    setTimeout(() => {
        document.querySelectorAll('.stagger-item').forEach((item, index) => {
            item.style.animationDelay = `${index * 0.1}s`;
            item.classList.remove('stagger-item');
            item.offsetHeight; // Force reflow
            item.classList.add('stagger-item');
        });
    }, 50);
}

// Search functionality
function searchPackages() {
    const searchTerm = document.getElementById('search-input').value.toLowerCase();
    
    if (!searchTerm) {
        displayPackages();
        return;
    }
    
    const filteredPackages = packages.filter(pkg => 
        pkg.name.toLowerCase().includes(searchTerm) ||
        pkg.description.toLowerCase().includes(searchTerm) ||
        pkg.location?.toLowerCase().includes(searchTerm) ||
        pkg.type.toLowerCase().includes(searchTerm)
    );
    
    const container = document.getElementById('packages-container');
    
    if (filteredPackages.length === 0) {
        container.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 3rem;">
                <p style="font-size: 1.2rem; color: #666;">No packages found for "${searchTerm}"</p>
                <button class="btn-primary" onclick="clearSearch()" style="margin-top: 1rem;">Clear Search</button>
            </div>
        `;
        return;
    }
    
    container.innerHTML = filteredPackages.map((pkg, index) => `
        <div class="package-card stagger-item" style="animation-delay: ${index * 0.1}s">
            <img src="${pkg.imageUrl}" alt="${pkg.name}" class="package-image">
            <div class="package-content">
                <span class="package-type ${pkg.type}">${pkg.type.toUpperCase()}</span>
                <h3 class="package-title">${pkg.name}</h3>
                <p class="package-description">${pkg.description}</p>
                ${pkg.location ? `<p><strong>Location:</strong> ${pkg.location}</p>` : ''}
                ${pkg.duration ? `<p><strong>Duration:</strong> ${pkg.duration}</p>` : ''}
                <div class="package-price">₹${pkg.price.toLocaleString()}</div>
                <button class="btn-primary" onclick="openBookingModal('${pkg._id}', '${pkg.name}')">
                    Book Now
                </button>
            </div>
        </div>
    `).join('');
}

function clearSearch() {
    document.getElementById('search-input').value = '';
    displayPackages();
}

// Filter by badge
function filterByBadge(type) {
    currentFilter = type;
    
    // Update active badge
    document.querySelectorAll('.badge').forEach(badge => {
        badge.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Update nav links too
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.classList.remove('active');
        if (link.dataset.filter === type) {
            link.classList.add('active');
        }
    });
    
    displayPackages();
}